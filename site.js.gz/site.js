
(()=>{const range=document.getElementById('baRange'),before=document.getElementById('baBefore'),divider=document.getElementById('baDivider');function update(){const v=range.value;before.style.clipPath=`inset(0 ${100-v}% 0 0)`;divider.style.left=v+'%'}range.addEventListener('input',update);update()})();

(()=>{document.querySelectorAll('.client-logo img').forEach(img=>img.addEventListener('error',()=>img.closest('.client-logo').classList.add('fallback')));})();
(()=>{const items=document.querySelectorAll('.reveal');if(!('IntersectionObserver'in window)){items.forEach(el=>el.classList.add('visible'));return}const io=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');io.unobserve(e.target)}}),{threshold:.08});items.forEach(el=>io.observe(el))})();

